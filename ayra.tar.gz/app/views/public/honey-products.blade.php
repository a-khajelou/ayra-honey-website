@extends('public.base')
@section('body')
<!--=======content================================-->


<div class="container_12">
    <div class="grid_12">

        <img src="/static/images/big_pic1.jpg" alt="" class="img3">

        <h2 class="txt_cntr">Honey Products</h2>

        <div class="grid_4 alpha">
            <div class="wrapper marBot1">
                <img src="/static/images/page2_pic1.jpg" alt="" class="img4 no_resize">

                <div class="box">
                    <h3 class="v2">In pede mi</h3>

                    <p>Quisa. Vestibulum libero nisl, porta vel, scelerisque eget, malesa at, neque. Vivamuscursus leo
                        vel metusulla facilisi.</p>
                    <a href="#" class="more_btn2">read more</a>
                </div>
            </div>
            <div class="wrapper marBot1">
                <img src="/static/images/page2_pic2.jpg" alt="" class="img4 no_resize">

                <div class="box">
                    <h3 class="v2">In pede mi</h3>

                    <p>Quisa. Vestibulum libero nisl, porta vel, scelerisque eget, malesa at, neque. Vivamuscursus leo
                        vel metusulla facilisi.</p>
                    <a href="#" class="more_btn2">read more</a>
                </div>
            </div>
            <div class="wrapper marBot1">
                <img src="/static/images/page2_pic3.jpg" alt="" class="img4 no_resize">

                <div class="box">
                    <h3 class="v2">In pede mi</h3>

                    <p>Quisa. Vestibulum libero nisl, porta vel, scelerisque eget, malesa at, neque. Vivamuscursus leo
                        vel metusulla facilisi.</p>
                    <a href="#" class="more_btn2">read more</a>
                </div>
            </div>
            <div class="wrapper">
                <img src="/static/images/page2_pic4.jpg" alt="" class="img4 no_resize">

                <div class="box">
                    <h3 class="v2">In pede mi</h3>

                    <p>Quisa. Vestibulum libero nisl, porta vel, scelerisque eget, malesa at, neque. Vivamuscursus leo
                        vel metusulla facilisi.</p>
                    <a href="#" class="more_btn2">read more</a>
                </div>
            </div>
        </div>

        <div class="grid_4">
            <div class="wrapper marBot1">
                <img src="/static/images/page2_pic5.jpg" alt="" class="img4 no_resize">

                <div class="box">
                    <h3 class="v2">In pede mi</h3>

                    <p>Quisa. Vestibulum libero nisl, porta vel, scelerisque eget, malesa at, neque. Vivamuscursus leo
                        vel metusulla facilisi.</p>
                    <a href="#" class="more_btn2">read more</a>
                </div>
            </div>
            <div class="wrapper marBot1">
                <img src="/static/images/page2_pic6.jpg" alt="" class="img4 no_resize">

                <div class="box">
                    <h3 class="v2">In pede mi</h3>

                    <p>Quisa. Vestibulum libero nisl, porta vel, scelerisque eget, malesa at, neque. Vivamuscursus leo
                        vel metusulla facilisi.</p>
                    <a href="#" class="more_btn2">read more</a>
                </div>
            </div>
            <div class="wrapper marBot1">
                <img src="/static/images/page2_pic7.jpg" alt="" class="img4 no_resize">

                <div class="box">
                    <h3 class="v2">In pede mi</h3>

                    <p>Quisa. Vestibulum libero nisl, porta vel, scelerisque eget, malesa at, neque. Vivamuscursus leo
                        vel metusulla facilisi.</p>
                    <a href="#" class="more_btn2">read more</a>
                </div>
            </div>
            <div class="wrapper ">
                <img src="/static/images/page2_pic8.jpg" alt="" class="img4 no_resize">

                <div class="box">
                    <h3 class="v2">In pede mi</h3>

                    <p>Quisa. Vestibulum libero nisl, porta vel, scelerisque eget, malesa at, neque. Vivamuscursus leo
                        vel metusulla facilisi.</p>
                    <a href="#" class="more_btn2">read more</a>
                </div>
            </div>
        </div>

        <div class="grid_4 omega">
            <div class="wrapper marBot1">
                <img src="/static/images/page2_pic9.jpg" alt="" class="img4 no_resize">

                <div class="box">
                    <h3 class="v2">In pede mi</h3>

                    <p>Quisa. Vestibulum libero nisl, porta vel, scelerisque eget, malesa at, neque. Vivamuscursus leo
                        vel metusulla facilisi.</p>
                    <a href="#" class="more_btn2">read more</a>
                </div>
            </div>
            <div class="wrapper marBot1">
                <img src="/static/images/page2_pic10.jpg" alt="" class="img4 no_resize">

                <div class="box">
                    <h3 class="v2">In pede mi</h3>

                    <p>Quisa. Vestibulum libero nisl, porta vel, scelerisque eget, malesa at, neque. Vivamuscursus leo
                        vel metusulla facilisi.</p>
                    <a href="#" class="more_btn2">read more</a>
                </div>
            </div>
            <div class="wrapper marBot1">
                <img src="/static/images/page2_pic11.jpg" alt="" class="img4 no_resize">

                <div class="box">
                    <h3 class="v2">In pede mi</h3>

                    <p>Quisa. Vestibulum libero nisl, porta vel, scelerisque eget, malesa at, neque. Vivamuscursus leo
                        vel metusulla facilisi.</p>
                    <a href="#" class="more_btn2">read more</a>
                </div>
            </div>
            <div class="wrapper">
                <img src="/static/images/page2_pic12.jpg" alt="" class="img4 no_resize">

                <div class="box">
                    <h3 class="v2">In pede mi</h3>

                    <p>Quisa. Vestibulum libero nisl, porta vel, scelerisque eget, malesa at, neque. Vivamuscursus leo
                        vel metusulla facilisi.</p>
                    <a href="#" class="more_btn2">read more</a>
                </div>
            </div>
        </div>

    </div>
</div>

</div>
@stop