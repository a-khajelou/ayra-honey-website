@include('public.header')
@section('body')
@show
@include('public.footer')
@section('js')
@show
</body>
</html>